# core/dashboard.py
"""Datos reales para el dashboard de inicio (templates/bienvenida.html).

Uso en core/views.py:

    from core.dashboard import contexto_dashboard

    def bienvenida(request):
        context = {...lo que ya tenías, incluido 'modulos'...}
        context.update(contexto_dashboard(request.user))
        return render(request, 'bienvenida.html', context)

Si el usuario no ha iniciado sesión devuelve {} para no exponer cifras de
ventas ni clientes en la portada pública; el template muestra entonces las
tarjetas de módulos y una invitación a entrar.
"""
import platform
from datetime import date, timedelta

import django
from django.db.models import Count, DecimalField, ExpressionWrapper, F, Sum
from django.db.models.functions import TruncDate, TruncMonth
from django.utils import timezone

UMBRAL_STOCK = 5     # por debajo de este stock el producto sale en alertas
PALETA = ['#ff3b30', '#ff5e36', '#ff8566', '#ffb199', '#5b5b6b']
DIAS = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom']
MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun',
         'jul', 'ago', 'sep', 'oct', 'nov', 'dic']

_MONTO = ExpressionWrapper(
    F('cantidad') * F('precio_unitario'),
    output_field=DecimalField(max_digits=14, decimal_places=2),
)
_VALOR = ExpressionWrapper(
    F('precio') * F('stock'),
    output_field=DecimalField(max_digits=14, decimal_places=2),
)


def _ultimos_meses(hoy: date, n: int = 6) -> list:
    """Primer día de cada uno de los últimos n meses (el más antiguo primero)."""
    meses = []
    for i in range(n - 1, -1, -1):
        mes, anio = hoy.month - i, hoy.year
        while mes <= 0:
            mes += 12
            anio -= 1
        meses.append(date(anio, mes, 1))
    return meses


def contexto_dashboard(user) -> dict:
    """Devuelve el contexto del dashboard o {} si no hay sesión."""
    if not getattr(user, 'is_authenticated', False):
        return {}

    # Importes diferidos: evita ciclos al cargar las URLs del proyecto.
    from clientes.models import Cliente
    from productos.models import Producto
    from proveedores.models import Proveedor
    from ventas.models import DetalleVenta, Venta

    hoy = timezone.localdate()

    # ── Ventas: ingresos de los últimos 7 días ─────────────────────────────
    inicio = hoy - timedelta(days=6)
    filas = (DetalleVenta.objects
             .filter(venta__fecha__date__gte=inicio)
             .annotate(dia=TruncDate('venta__fecha'))
             .values('dia').annotate(total=Sum(_MONTO)))
    por_dia = {f['dia']: f['total'] for f in filas}
    dias = [inicio + timedelta(days=i) for i in range(7)]
    ventas_valores = [float(por_dia.get(d) or 0) for d in dias]
    ventas_labels = [DIAS[d.weekday()] for d in dias]
    ingresos_semana = sum(ventas_valores)
    ventas_semana = Venta.objects.filter(fecha__date__gte=inicio).count()

    # ── Clientes: activos acumulados por mes (6 meses) ────────────────────
    meses = _ultimos_meses(hoy)
    nuevos = {
        (f['mes'].year, f['mes'].month): f['n']
        for f in (Cliente.objects
                  .filter(activo=True, creado__date__gte=meses[0])
                  .annotate(mes=TruncMonth('creado'))
                  .values('mes').annotate(n=Count('id')))
    }
    acumulado = Cliente.objects.filter(activo=True, creado__date__lt=meses[0]).count()
    clientes_serie = []
    for m in meses:
        acumulado += nuevos.get((m.year, m.month), 0)
        clientes_serie.append(acumulado)
    clientes_total = Cliente.objects.filter(activo=True).count()

    # ── Productos: unidades en stock por categoría + valor del inventario ──
    stock_cat = list(
        Producto.objects.filter(activo=True)
        .values(nombre=F('categoria__nombre'))
        .annotate(unidades=Sum('stock')).order_by('-unidades')[:5]
    )
    resumen = Producto.objects.filter(activo=True).aggregate(
        n=Count('id'), valor=Sum(_VALOR))
    alertas_qs = (Producto.objects
                  .filter(activo=True, stock__lt=UMBRAL_STOCK)
                  .select_related('categoria').order_by('stock', 'nombre'))
    alertas_total = alertas_qs.count()

    # ── Reportes: ingresos por categoría (histórico) ───────────────────────
    cats = list(
        DetalleVenta.objects
        .values(nombre=F('producto__categoria__nombre'))
        .annotate(total=Sum(_MONTO)).order_by('-total')[:5]
    )
    total_cats = DetalleVenta.objects.aggregate(t=Sum(_MONTO))['t'] or 0
    categorias = [{
        'nombre': c['nombre'], 'total': c['total'], 'color': PALETA[i],
        'pct': round(float(c['total']) / float(total_cats) * 100) if total_cats else 0,
    } for i, c in enumerate(cats)]

    return {
        'django_version': django.get_version(),
        'python_version': platform.python_version(),
        'umbral_stock': UMBRAL_STOCK,

        'productos_activos': resumen['n'],
        'valor_inventario': resumen['valor'] or 0,
        'clientes_total': clientes_total,
        'ingresos_semana': ingresos_semana,
        'ventas_semana': ventas_semana,
        'hay_ventas_semana': any(ventas_valores),
        'hay_stock': bool(stock_cat),
        'categorias': categorias,

        'ultimas_ventas': (Venta.objects.select_related('cliente')
                           .prefetch_related('detalles')[:5]),
        'proveedores_top': Proveedor.objects.filter(activo=True)[:3],
        'alertas': alertas_qs[:4],
        'alertas_total': alertas_total,

        # Se serializa en el template con |json_script
        'dash_json': {
            'stock': {'labels': [c['nombre'] for c in stock_cat],
                      'data': [c['unidades'] or 0 for c in stock_cat]},
            'clientes': {'labels': [f'{MESES[m.month - 1]}' for m in meses],
                         'data': clientes_serie},
            'ventas': {'labels': ventas_labels, 'data': ventas_valores},
            'categorias': {'labels': [c['nombre'] for c in categorias],
                           'data': [float(c['total']) for c in categorias],
                           'colors': [c['color'] for c in categorias]},
        },
    }
